<?php

namespace App\Notifications;

use App\Http\Controllers\CommonLaravel\Helpers\UserHelper;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\BroadcastMessage;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Log;

class AddedModel extends Notification {
    use Queueable;

    public $model_name;
    public $model_id;

    public function __construct($model_name, $model_id) {
        $this->model_name = $model_name;
        $this->model_id = $model_id;
    }

    public function via($notifiable) {
        return ['broadcast'];
    }

    public function broadcastOn() {
        Log::info('broadcast por canal: '.'added_model.'.UserHelper::userId());
        return 'added_model.'.UserHelper::userId();
    }

    public function toBroadcast($notifiable) {
        return new BroadcastMessage([
            'model_name'    => $this->model_name,
            'model_id'      => $this->model_id,
            'added_by'      => UserHelper::userId(false),
        ]);
    }
}
