<?php

namespace App\Http\Controllers\Helpers;

use Carbon\Carbon;

class __name__Helper {
	
}