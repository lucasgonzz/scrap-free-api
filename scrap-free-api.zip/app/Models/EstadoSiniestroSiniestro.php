<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class EstadoSiniestroSiniestro extends Pivot
{
    protected $table = 'estado_siniestro_siniestro';
}
