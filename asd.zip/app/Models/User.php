<?php

namespace App\Models;

use App\Http\Controllers\CommonLaravel\Helpers\GeneralHelper;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $guarded = [];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    function scopeWithAll($q) {
        $q->with('permissions');
    }

    function permissions() {
        return $this->belongsToMany(GeneralHelper::getModelName(env('PERMISSION_CLASS_NAME', 'Permission')));
    }
}
